
A new-package review request has been submitted within the Fedora project:

  https://bugzilla.redhat.com/show_bug.cgi?id=666301

and, pending a successful review and the presence of the necessary dependencies,
the libLAS package will eventually be modified to support current Fedora and
EPEL (CentOS, RHEL) versions.

In the mean time, a copy of the submitted RPM spec file is included here.

-- Ed Hill <ed@eh3.com>

