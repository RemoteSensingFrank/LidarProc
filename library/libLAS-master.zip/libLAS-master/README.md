# libLAS

http://liblas.org

## Build Status

| Branch | Travis CI | AppVeyor | Coverity |
|:--- |:--- |:--- |:--- |
|`master`| [![master](https://travis-ci.org/libLAS/libLAS.svg?branch=master)](https://travis-ci.org/libLAS/libLAS/) | [![master](https://ci.appveyor.com/api/projects/status/r2ajb1qwe9rh0xkd/branch/master?svg=true)](https://ci.appveyor.com/project/mloskot/liblas?branch=master) | [![coverity_scan](https://scan.coverity.com/projects/10975/badge.svg)](https://scan.coverity.com/projects/liblas-liblas) |
